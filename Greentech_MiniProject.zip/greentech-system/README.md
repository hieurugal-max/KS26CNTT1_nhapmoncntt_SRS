# He thong quan tri ha tang GreenTech

## Muc dich
Quan ly tai lieu, loc log su co va doi soat linh kien cho cac tram cam bien IoT.

## Cau truc du an
```text
greentech-system/
├── docs/
│   ├── README.md
│   └── srs-he-thong.docx
├── scripts/
│   └── auto_report.bat
├── data/
│   ├── log-he-thong.log
│   └── quan-ly-thiet-bi.xlsx
├── backup/
│   └── bao-cao-su-co.txt
├── .env.example
└── .gitignore
```

## IPO
- **Input:** `data/log-he-thong.log`.
- **Process:** `auto_report.bat` loc `CRITICAL`, `ERROR`, `TIMEOUT` bang `findstr`.
- **Output:** `backup/bao-cao-su-co.txt`.

## DIKW
- **Data:** log tho phat sinh tu may chu.
- **Information:** cac dong log da loc theo tu khoa loi.
- **Knowledge:** nhan ra loi lap lai hoac tram co nhieu su co.
- **Wisdom:** quyet dinh kiem tra thiet bi, dieu chinh cau hinh hoac nang cap ket noi.

## Chay script
Mo Command Prompt tai thu muc goc du an va chay:
```bat
scripts\auto_report.bat
```
Script kiem tra file dau vao truoc khi chay, chi doc log va ghi noi bao cao, khong dung lenh xoa.

## Checklist kiem tra thiet bi
- [ ] Kiem tra ket noi tram cam bien.
- [ ] Kiem tra dung luong RAM va SSD.
- [ ] Chay script loc log.
- [ ] Kiem tra bao cao trong `backup/`.
- [ ] Doi chieu ma linh kien trong Excel.
- [ ] Sao luu bao cao sau khi kiem tra.

## Bang thong so phan cung mau
| Thiet bi | Thong so mau | Vai tro |
|---|---|---|
| CPU | ARM Cortex-A53 | Xu ly du lieu cam bien |
| RAM | 4 GB | Chay dich vu thu thap du lieu |
| SSD | 128 GB | Luu du lieu cuc bo |
| Ket noi | Ethernet/Wi-Fi | Gui du lieu ve may chu |

## Doi soat Excel
```excel
=IFERROR(VLOOKUP(TRIM(B2),'danh-muc-linh-kien'!$A$2:$D$6,2,FALSE),"KHONG TIM THAY MA")
```
`TRIM` loai bo khoang trang thua, `FALSE` yeu cau khop chinh xac va `$` co dinh vung tra cuu.

## Tinh thoi gian tai log
`MB/s = Mbps / 8`; `Thoi gian (giay) = dung luong (MB) / toc do (MB/s)`.
Vi du 500 MB qua mang 100 Mbps: toc do ly thuyet 12,5 MB/s, thoi gian khoang 40 giay, chua tinh hao hut mang.

## Bao mat
Khong dua mat khau that len GitHub. `.env.example` chi chua gia tri gia lap; `.env` nam trong `.gitignore`.
