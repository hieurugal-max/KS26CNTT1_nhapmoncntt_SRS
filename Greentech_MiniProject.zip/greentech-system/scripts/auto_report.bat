@echo off
setlocal
REM AUDIT: kiem tra nguon truoc khi doc; khong xoa du lieu.
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "LOG_FILE=%ROOT%\data\log-he-thong.log"
set "BACKUP_DIR=%ROOT%\backup"
set "REPORT=%BACKUP_DIR%\bao-cao-su-co.txt"
echo [AUDIT] Kiem tra file nguon va thu muc dau ra.
if not exist "%LOG_FILE%" (
  echo [ERROR] Khong tim thay file log: "%LOG_FILE%"
  exit /b 1
)
if not exist "%BACKUP_DIR%\" mkdir "%BACKUP_DIR%"
if not exist "%BACKUP_DIR%\" exit /b 1
echo.>>"%REPORT%"
echo ================================================>>"%REPORT%"
echo BAO CAO SU CO HE THONG GREENTECH>>"%REPORT%"
echo Thoi gian chay: %DATE% %TIME%>>"%REPORT%"
echo Nguon: data\log-he-thong.log>>"%REPORT%"
echo ================================================>>"%REPORT%"
type "%LOG_FILE%" | findstr /I /C:"CRITICAL" /C:"ERROR" /C:"TIMEOUT" >>"%REPORT%"
if errorlevel 2 (
  echo [ERROR] Co loi khi doc hoac loc file log.
  exit /b 2
)
echo [OK] Da ghi noi bao cao. Khong co lenh xoa tep.
exit /b 0
