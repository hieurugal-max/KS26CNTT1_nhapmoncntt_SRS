@echo off
setlocal
cd /d "%~dp0.."

if not exist "data\log-he-thong.log" (
    echo Khong tim thay data\log-he-thong.log
    exit /b 1
)

if not exist "backup\bao-cao-su-co.txt" type nul > "backup\bao-cao-su-co.txt"

echo ===== BAO CAO SU CO HE THONG =====>>"backup\bao-cao-su-co.txt"
echo Thoi gian chay: %date% %time%>>"backup\bao-cao-su-co.txt"
type "data\log-he-thong.log" | findstr /I "CRITICAL ERROR TIMEOUT">>"backup\bao-cao-su-co.txt"
echo.>>"backup\bao-cao-su-co.txt"

echo Hoan tat loc log.
endlocal
