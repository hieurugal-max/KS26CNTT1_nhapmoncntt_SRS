# Tai lieu du an

Tai lieu SRS chinh: `srs-he-thong.docx`.

De cap nhat muc luc trong Word, bam `Ctrl+A`, sau do bam `F9` va chon cap nhat toan bo muc luc.
