# He thong quan tri ha tang GreenTech K26

## Gioi thieu
Du an mo phong quan ly thiet bi ha tang va tu dong loc nhat ky su co.

## Cau truc thu muc
- `docs/`: tai lieu ky thuat va SRS.
- `scripts/`: script tu dong hoa.
- `data/`: log he thong va bang du lieu thiet bi.
- `backup/`: bao cao su co duoc luu lai.

## Cach chay script
Mo CMD tai thu muc goc du an va chay:

```bat
scripts\auto_report.bat
```

Script loc cac dong chua `CRITICAL`, `ERROR` hoac `TIMEOUT` tu `data\log-he-thong.log`, sau do noi ket qua vao `backup\bao-cao-su-co.txt`.

## Checklist kiem tra
- [ ] Kiem tra ket noi tram cam bien
- [ ] Kiem tra dung luong RAM
- [ ] Doi chieu ma linh kien
- [ ] Kiem tra bao cao su co

## Thong so tram mau
| Tram | RAM | Ngay lap dat |
|---|---|---|
| tram-01 | 4GB | 2026-01-10 |
| tram-02 | 8GB | 2026-02-15 |

## Bao mat
Khong dua file `.env` chua thong tin that len GitHub cong khai. Su dung `.env.example` voi gia tri mau va `.gitignore` de loai `.env` khoi Git.
